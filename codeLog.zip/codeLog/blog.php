<?php include_once("header.php") ?>    

    <main class="container blog">

        <article>

            <h2>I Stopped Using Kubernetes. Our DevOps Team Is Happier Than Ever</h2>

            <div class="centerImg">
                <img src="img/Kubernetes.webp" alt="">
            </div>

            <div>
                <hr>
                    <a href=""><i class="bi bi-heart"></i></a>
                    <!-- <a href=""><i class="bi bi-heart-fill"></i></a> -->

                    <a style="margin-left: 20px;" href=""><i class="bi bi-play-circle"></i></a>
                    <a style="margin-left: 20px;" href=""><i class="bi bi-box-arrow-up"></i></a>
                <hr>
            </div>

            <p class="post">
                Six months ago, our DevOps team was drowning in complexity. We were managing 47 Kubernetes clusters
                across three cloud providers.

                Our engineers were working weekends. On-call rotations were dreaded. Then we made a decision that
                seemed crazy at the time — we started removing Kubernetes from our stack.

                Today, our deployment success rate is up by 89%. Infrastructure costs are down 62%. And for the
                first time in two years, our DevOps team took uninterrupted vacations.

                Here's the story.

                The Kubernetes Dream vs. Reality
                Like many companies, we jumped on the Kubernetes bandwagon three years ago. The promises were
                compelling:

                Container orchestration at scale
                Cloud-native architecture
                Infrastructure as code
                Automated scaling and healing
                And yes, Kubernetes delivered on these promises. But it came with hidden costs that nobody talked
                about.
            </p>

        </article>

        <article>
            <h3>Comments</h3>
            <textarea name="comment" placeholder="Write a commnet..."
                aria-label="Comment"></textarea> <br>

            <small><b>Jony Devnath</b> </small> <br>
            <small> ~Thanks a lots. Learn lot of things</small> <br> <br>

            <small><b>Jony Devnath</b> </small> <br> 
            <small> ~Thanks a lots. Learn lot of things</small> <br> <br>

        </article>

    </main>

<?php include_once("footer.php") ?>    
