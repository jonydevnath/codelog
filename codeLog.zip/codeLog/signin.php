<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <main class="container-fluid center">

        <h1>Code Log</h1>

        <form action="" method="post">
            <input type="email" name="email" placeholder="Email" aria-label="Email" autocomplete="email">
            <input type="password" name="password" placeholder="Password" aria-label="Password">
            <input type="submit" value="Sign in">
        </form>

        <small>No account? <a href="signup.php">Create one</a></small>

    </main>

</body>

</html>