<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Log</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <nav class="container">
        <ul>
            <li><a href="index.php"><h3>Code Log</h3></a></li>
        </ul>
        <ul>
            <li>
                <input type="search" name="search" placeholder="Search" aria-label="Search" />
            </li>
        </ul>
        <ul>
            <li><a href="signin.php" class="secondary">Sign in</a></li>
            <li>
                <details class="dropdown">
                    <summary>
                        Jhon <!-- write the first name  -->
                    </summary>
                    <ul dir="rtl">
                        <li><a href="profile.php">Profile</a></li>
                        <li><a href="#">Logout</a></li>
                    </ul>
                </details>
            </li>
        </ul>
    </nav>