<?php include_once("header.php") ?>

    <section class="container hero">
        <h1>
            Unleash
        </h1>
        <p class="secondary">
            The Power of Knowledge - Code, Create, Conquer"
        </p>
    </section>

    <main class="container">

        <section class="grid">

            <article class="post">
                <div class="centerImg">
                    <img src="img/Kubernetes.webp" alt="">
                </div>

                <h5>I Stopped Using Kubernetes. Our DevOps Team Is Happier Than Ever</h5>

                <p>
                    Six months ago, our DevOps team was drowning in complexity. We were managing 47 Kubernetes clusters
                    across three cloud providers.
                </p>

                <a href="blog.php">read more...</a>
            </article>

            <article class="post">
                <div class="centerImg">
                    <img src="img/Kubernetes.webp" alt="">
                </div>

                <h5>I Stopped Using Kubernetes. Our DevOps Team Is Happier Than Ever</h5>

                <p>
                    Six months ago, our DevOps team was drowning in complexity. We were managing 47 Kubernetes clusters
                    across three cloud providers.
                </p>

                <a href="#">read more...</a>
            </article>

            <article class="post">
                <div class="centerImg">
                    <img src="img/Kubernetes.webp" alt="">
                </div>

                <h5>I Stopped Using Kubernetes. Our DevOps Team Is Happier Than Ever</h5>

                <p>
                    Six months ago, our DevOps team was drowning in complexity. We were managing 47 Kubernetes clusters
                    across three cloud providers.
                </p>

                <a href="#">read more...</a>
            </article>

            <article class="post">
                <div class="centerImg">
                    <img src="img/Kubernetes.webp" alt="">
                </div>

                <h5>I Stopped Using Kubernetes. Our DevOps Team Is Happier Than Ever</h5>

                <p>
                    Six months ago, our DevOps team was drowning in complexity. We were managing 47 Kubernetes clusters
                    across three cloud providers.
                </p>

                <a href="#">read more...</a>
            </article>


        </section>

        <div class="btn">
            <button class="outline" id="load-more">load more</button>
        </div>

    </main>

    <section class="container newsletter">

        <div class="grid">

            <div>
                <h6>Subscribe to Our Newsletter</h6>
                <form>
                    <fieldset role="group">
                        <input name="email" type="email" placeholder="Enter your email" autocomplete="email" />
                        <input type="submit" value="Subscribe" />
                    </fieldset>
                </form>
                <small>We respect your privacy. No spam, ever.</small>
            </div>

            <div class="social">
                <div class="media">
                    <a href="https://facebook.com" target="_blank" style="margin-right: 30px; "><i
                            class="bi bi-facebook"></i></a>
                    <a href="https://twitter.com" target="_blank" style="margin-right: 30px;"><i
                            class="bi bi-twitter-x"></i></a>
                    <a href="https://instagram.com" target="_blank"><i class="bi bi-instagram"></i></a>
                </div>
            </div>

        </div>

    </section>

<?php include_once("footer.php") ?>    