document.addEventListener('DOMContentLoaded', () => {
    const posts = document.querySelectorAll('.post');
    const loadMoreBtn = document.getElementById('load-more');
    let visiblePosts = 2; // Number of posts initially visible
  
    // Function to show initial posts
    const showPosts = () => {
      posts.forEach((post, index) => {
        if (index < visiblePosts) {
          post.style.display = 'block';
        }
      });
    };
  
    // Event listener for Load More button
    loadMoreBtn.addEventListener('click', () => {
      visiblePosts += 3; // Increase the number of visible posts
      showPosts();
  
      // Hide the button if all posts are visible
      if (visiblePosts >= posts.length) {
        loadMoreBtn.style.display = 'none';
      }
    });
  
    // Initial call to show posts
    showPosts();
  });
  