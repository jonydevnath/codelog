<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Log</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>

    <main class="container">

        <article class="left">
            <a href="allpost.php" style="text-decoration: none;">
                <h3>Code Log Admin</h3>
            </a>

            <a href="allpost.php" class="custom-link active">All Post</a><br>
            <a href="admin_pass.php" class="custom-link">Change Password</a><br>
            <a href="logout.php" class="custom-link">Logout</a>

            <br><br>

            <small>
                <a href="index.php" target="_blank" style="text-decoration: none;">
                    Visit CodeLog
                </a>
            </small>

        </article>

        <article class="right">
            <a href="create.php"><button class="outline">Create Post</button></a>
            <br><br>

            <table>
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Title</th>
                        <th scope="col">Image</th>
                        <th scope="col">Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">01</th>

                        <td>
                            <p>
                                I Stopped Using Kubernetes. Our DevOps Team Is Happier Than Ever
                            </p>
                        </td>

                        <td style="width: 20%;">
                            <img src="img/Kubernetes.webp" alt="">
                        </td>
                        <td>
                            <a href="edit.php"><i class="bi bi-pencil-square"></i></a>

                            <a href="delete.php" style="margin-left: 20px; color:#ff6347;"
                                onclick="return confirm('Are you sure you want to delete this post?');">
                                <i class="bi bi-trash"></i>
                            </a>

                        </td>

                    </tr>

                </tbody>

            </table>


        </article>

    </main>

    <script src="scripts.js"></script>
</body>

</html>