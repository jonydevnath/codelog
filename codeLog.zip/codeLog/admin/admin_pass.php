<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Log</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>

    <main class="container">

        <article class="left">
            <h3>Code Log Admin</h3>

            <a href="allpost.php" class="custom-link">All Post</a><br>
            <a href="admin_pass.php" class="custom-link active">Change Password</a><br>
            <a href="logout.php" class="custom-link">Logout</a>
        </article>

        <article class="right">
            <h3>Change Password</h3>
            <form action="" method="post">
                <label>
                    Current Password
                    <input type="password" name="password" placeholder="Password" aria-label="Password">
                </label>

                <label>
                    New Password
                    <input type="password" name="new_password" placeholder="New Password"
                        aria-label="New Password">
                </label>

                <label>
                    Confirm Password
                    <input type="password" name="confirm_password" placeholder="Confirm Password"
                        aria-label="Confirm Password">
                </label>

                <input type="submit" value="Update Password" />
            </form>

        </article>

    </main>

    <script src="scripts.js"></script>
</body>

</html>