<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Log</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>

    <main class="container">

        <article class="left">
            <h3>Code Log Admin</h3>

            <a href="allpost.php" class="custom-link">All Post</a><br>
            <a href="admin_pass.php" class="custom-link">Change Password</a><br>
            <a href="logout.php" class="custom-link">Logout</a>
        </article>

        <article class="right">
            <h3>Create Post</h3>

            <form action="" method="post">
                <label>
                    Title
                    <input type="text" name="title" placeholder="Title" aria-label="Title">
                </label>

                <label>
                    Upload Image
                    <input type="file">
                </label>

                <label>
                    Write a post
                    <textarea name="post" placeholder="Write what you are thinking..." aria-label="Write post"
                        style="height: 500px;">
                </textarea>
                </label>

                <input type="submit" value="Post" />
            </form>

        </article>

    </main>

    <script src="scripts.js"></script>
</body>

</html>